﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Personal : Persona
    {
        public string Nip { get; set; }
        public string cuil { get; set; }

    }
}
