﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Cliente : Persona
    {
        public string Cuil { get; set; }
        public string nombreEmpresa { get; set; }      
        public Domicilio domicilioEmpresa { get; set; }

        public Pasillo nuevoPasillo { get; set; }
        public Lado nuevoLado { get; set; }
        public Compartimiento nuevoCompartimiento { get; set; }
        public Producto nuevoProducto { get; set; }
    }
}
