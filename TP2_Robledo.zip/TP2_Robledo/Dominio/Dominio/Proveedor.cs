﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Proveedor : Persona
    {
        public string Cuit { get; set; }
        public string  nombreEmpresa { get; set; }
        public Domicilio domicilioProveedor { get; set; }

        public Producto nuevoProducto { get; set; }

    }
}
